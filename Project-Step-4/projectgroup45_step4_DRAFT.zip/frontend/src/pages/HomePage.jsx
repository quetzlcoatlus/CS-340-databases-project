import React from 'react';

function HomePage() {
    return (
        <div>
            <h2>Welcome to the Fleet Management System</h2>
            <p>Select an entity from the navigation bar to view data or make changes.</p>
        </div>
    );
}

export default HomePage;